public class RandomNumber {
    static int number;
    public static int randomNumber(){
        number=(int)(Math.random()  * 100) + 1;
        //System.out.println(number);
        return number;
    }
}
