import java.util.Scanner;

public class Main {
    static Scanner input=new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("\t\t\tWelcome to Number Game");
        System.out.println("\t\t  --------------------------");
        System.out.println();
        System.out.println();
        login();
    }
    public static void login(){
        System.out.println("Click \"1\" to play New Game\nClick \"0\" to Exit");
        System.out.println();
        System.out.print("Enter Your Choice : ");

        int choice=input.nextInt();
        while(true){
            if(choice==0){
                System.out.println("Exit");
                System.exit(0);
                break;
            }
            else if (choice==1) {
                RandomNumber.randomNumber();
                User.play();
                break;
            }
            else{
                System.out.print("Please Enter either 1 or 0 : ");
                choice=input.nextInt();

            }
        }
    }
}