import java.util.Scanner;

public class User {
    public static void play() {
        int count = 1;
        Scanner sc=new Scanner(System.in);
        boolean isvalid = false;
        while (!isvalid) {
            if (count <= 10) {
                System.out.print("Enter a Number (1 to 100) : ");
                int input = sc.nextInt();
                while (true) {
                    if (input > 100 || input < 1) {
                        System.out.print("please Enter a number from 1 to 100 : ");
                        input = sc.nextInt();
                    } else {
                        break;
                    }
                }
                if (RandomNumber.number == input) {
                    System.out.println();
                    System.out.println("Congrats! You Won the game on " + count + " round");
                    isvalid = true;
                } else {
                    int difference =Math.abs(input - RandomNumber.number);
                    if (difference >= 70) {
                        System.out.println("Your Guess too far");
                    } else if (difference >= 40) {
                        System.out.println("Your Guess is far");
                    } else if (difference >= 20 ) {
                        System.out.println("Your Guess is close");
                    } else{
                        System.out.println("Your Guess is too Close");
                    }
                    count++;
                    System.out.println();
                    if(count<=10) {
                        System.out.println("Try Again");
                    }
                }
            } else {
                System.out.println("Your Attempts all are Over ");
                System.out.println("The Correct Answer was : " + RandomNumber.number);
                isvalid=true;
            }

        }
        System.out.println("----------------------------------");
        System.out.println();
        Main.login();
    }
}
